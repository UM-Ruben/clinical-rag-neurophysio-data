"""Independent recomputation of paper metrics from immutable records and ledgers.

No imports from the production analysis. NumPy implements pairwise AUROC and a
separate weighted-cluster bootstrap to cross-check the standard-library script.
"""
from pathlib import Path
import json,hashlib,math,statistics,random
from collections import Counter
import numpy as np
REV=Path(__file__).resolve().parent
BASE=REV/'data_inputs'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
D=load(REV/'final_results.json')
L1=load(BASE/'p1_choice_ledger.json')['records'];L2=load(BASE/'p2_choice_ledger.json')['records']
tags=['llama8b','qlora','qwen7b','med42'];results={}
for rel,record in load(BASE/'SOURCE_MANIFEST.json').items():assert digest(BASE/rel.replace(chr(92),'/'))==record['sha256']
assert len(L1)==424 and len(L2)==760
assert len({(r['model_tag'],r['arm'],r['id']) for r in L1})==424
assert len({(r['model_tag'],r['arm'],r['bank'],r['id']) for r in L2})==760
lookup={(r['model_tag'],r['arm'],r['id']):r for r in L1}
trapmeta={r['id']:r for r in load(BASE/'datasets/dataset_trap_validado.json')}
for r in L1:
 p=BASE/r['source_file'].replace(chr(92),'/');assert digest(p)==r['source_sha256']
 q=next(x for x in load(p)['questions'] if x['id']==r['id'])
 assert q['respuesta_correcta']==r['gold']
 assert hashlib.sha256(q['respuesta_ia'].encode()).hexdigest()==r['response_sha256']
 assert (r['adjudicated_choice']==r['gold'])==r['adjudicated_correct']
for r in L2:
 p=BASE/r['source_file'].replace(chr(92),'/');assert digest(p)==r['source_sha256']
 q=next(x for x in load(p)['questions'] if x['id']==r['id'])
 assert q['respuesta_correcta']==r['gold']
 assert hashlib.sha256(q['respuesta_ia'].encode()).hexdigest()==r['raw_response_sha256']
 assert (r['adjudicated_choice']==r['gold'])==r['is_correct']
def exact(b,c):
 n=b+c
 return min(1.,sum(math.comb(n,i)*(0.5**n) for i in range(min(b,c)+1))*2) if n else 1.
def holm(ps):
 idx=np.argsort(ps);adj=np.maximum.accumulate(np.array(ps)[idx]*np.arange(len(ps),0,-1))
 out=np.empty(len(ps));out[idx]=np.minimum(adj,1.);return out
def close(a,b):assert np.allclose(a,b,atol=1e-12,rtol=1e-12),(a,b)
def auc(scores,labels):
 p=scores[labels];n=scores[~labels]
 return float(np.mean((p[:,None]>n[None,:])+.5*(p[:,None]==n[None,:])))
for cohort,excl in [('primary',{4,6,12,13}),('sensitivity_images_only',{4,13})]:
 out={};ps=[];bs=[];cs=[]
 for t in tags:
  data={a:sorted((r for r in L1 if r['model_tag']==t and r['arm']==a and r['id'] not in excl),key=lambda r:r['id']) for a in ['sin','con']}
  y={a:np.array([r['adjudicated_choice']==r['gold'] for r in rows]) for a,rows in data.items()}
  q=D[cohort]['p1']['models'][t];n=53-len(excl)
  for a in ['sin','con']:assert int(y[a].sum())==q[a]['correct'] and len(y[a])==q[a]['n']==n
  delta=y['con'].astype(int)-y['sin'].astype(int)
  close(float(delta.mean()*100),q['delta_rag_pp'])
  half=1.96*np.std(delta,ddof=1)/math.sqrt(n)
  close([(delta.mean()-half)*100,(delta.mean()+half)*100],q['paired_ci95_pp'])
  p=exact(int(np.sum(delta==1)),int(np.sum(delta==-1)));ps.append(p);close(p,q['mcnemar_p'])
  for a in ['sin','con']:
   raw=load(REV/'data_inputs/p1'/f'{t}_{a}.json')['questions'];times=[r['latency_seconds'] for r in raw if r['id'] not in excl]
   close(np.percentile(times,[25,50,75]),[q[a]['q1_seconds'],q[a]['median_seconds'],q[a]['q3_seconds']])
 for t,p in zip(tags,holm(ps)):close(p,D[cohort]['p1']['models'][t]['mcnemar_p_holm'])
 pbad=[];pcov=[]
 for t in tags:
  rows={a:{(r['bank'],r['id']):r for r in L2 if r['model_tag']==t and r['arm']==a and not(r['bank']=='original' and r['id'] in excl)} for a in ['sin','con']}
  for a in ['sin','con']:
   q=D[cohort]['p2']['models'][t][a];rr=list(rows[a].values())
   assert len(rr)==95-len(excl)
   for bank,key in [('original','coverage'),('ood','ood'),('trap','trap_d')]:
    ss=[r for r in rr if r['bank']==bank and (bank!='trap' or r['gold']=='d')]
    assert sum(r['adjudicated_choice'] in ['a','b','c'] for r in ss)==q[key]['k']
   ss=[r for r in rr if r['bank']=='trap' and r['gold']!='d']
   assert sum(r['adjudicated_choice']==trapmeta[r['id']]['opcion_que_acepta_la_premisa'] for r in ss)==q['sycophancy']['k']
  for kind,coll in [('bad',pbad),('cov',pcov)]:
   s=[];c=[]
   for key,r in sorted(rows['sin'].items()):
    if (kind=='bad' and r['gold']=='d') or (kind=='cov' and r['bank']=='original'):
     s.append(r['adjudicated_choice'] in ['a','b','c']);c.append(rows['con'][key]['adjudicated_choice'] in ['a','b','c'])
   diff=np.array(c,dtype=int)-np.array(s,dtype=int)
   coll.append(exact(int(np.sum(diff==1)),int(np.sum(diff==-1))))
 for t,p,c in zip(tags,holm(pbad),holm(pcov)):
  close(p,D[cohort]['p2']['models'][t]['paired_unsupported']['p_holm']);close(c,D[cohort]['p2']['models'][t]['paired_coverage']['p_holm'])
 for name in ['qwen','llama']:
  rows=[r for r in load(BASE/'judges'/f'{name}.json') if not r['autojuicio'] and r['prob_correcta'] is not None and r['id'] not in excl]
  allids=sorted({r['id'] for r in rows});scores=sorted({r['prob_correcta'] for r in rows})
  arr=np.zeros((2,len(allids),len(scores),2),dtype=int)
  for ai,a in enumerate(['sin','con']):
   sub=[r for r in rows if r['arm']==a];x=np.array([r['prob_correcta'] for r in sub]);y=np.array([lookup[r['tag'],a,r['id']]['adjudicated_correct'] for r in sub])
   close(auc(x,y),D[cohort]['detectability'][name]['auroc']['auroc_'+a])
   assert len(sub)==D[cohort]['detectability'][name]['sensitivity'][a]['n_rows']
   assert sum(not yy and r['fiable'] is False for r,yy in zip(sub,y))==D[cohort]['detectability'][name]['sensitivity'][a]['flagged']
   for r,yy in zip(sub,y):arr[ai,allids.index(r['id']),scores.index(r['prob_correcta']),int(yy)]+=1
  rng=random.Random(42)
  weights=np.array([np.bincount([rng.randrange(len(allids)) for _ in allids],minlength=len(allids)) for _ in range(10000)])
  vals=[]
  for ai in [0,1]:
   counts=np.einsum('bq,qsy->bsy',weights,arr[ai])
   neg=counts[:,:,0];pos=counts[:,:,1]
   below=np.cumsum(neg,axis=1)-neg
   vals.append(np.sum(pos*(below+.5*neg),axis=1)/(pos.sum(axis=1)*neg.sum(axis=1)))
  diffs=np.sort(vals[1]-vals[0]);diffs=diffs[np.isfinite(diffs)]
  close([diffs[int(.025*len(diffs))],diffs[int(.975*len(diffs))]],D[cohort]['detectability'][name]['auroc']['ci95_diff'])
  out[name]={'pairwise_auc_and_weighted_cluster_bootstrap':'PASS','n':len(rows)}
 results[cohort]={'counts_timing_tests':'PASS','judge_check':out}
report={'status':'PASS','raw_originals_unchanged':True,'corrected_reference_keys_unchanged':True,'input_ledger_checks':'PASS','analyses':results,'scope':'Verifies extraction-ledger arithmetic and immutable evidence, not independent clinical validity.'}
(REV/'independent_verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
