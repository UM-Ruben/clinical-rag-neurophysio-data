#!/usr/bin/env python3
"""Recompute corrected manuscript statistics without inference calls or SciPy.

Inputs are immutable saved responses and judge scores plus explicit adjudication
ledgers. Both the 49-item core and 51-item image-only sensitivity are post-hoc
subsets. Run: python recompute_results.py --data-root data_inputs
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import random
import statistics
from collections import defaultdict
from pathlib import Path

HERE=Path(__file__).resolve().parent
TAGS=['llama8b','qlora','qwen7b','med42']
EXCLUSIONS={'primary':[4,6,12,13],'sensitivity_images_only':[4,13]}

def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path,obj):
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8',newline='\n')

def exact_mcnemar(b,c):
    n=b+c
    return min(1.,2*sum(math.comb(n,k) for k in range(min(b,c)+1))/2**n) if n else 1.

def holm(ps):
    out={};prev=0.
    for i,k in enumerate(sorted(ps,key=ps.get)):
        prev=min(1.,max(prev,(len(ps)-i)*ps[k]));out[k]=prev
    return out

def wilson(k,n):
    if not n:return [0.,1.]
    z=1.959963984540054;p=k/n;d=1+z*z/n
    c=(p+z*z/(2*n))/d;m=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [max(0.,c-m),min(1.,c+m)]

def proportion(k,n):
    return {'k':k,'n':n,'pct':100*k/n if n else None,'ci95_wilson_pct':[100*x for x in wilson(k,n)]}

def auc(rows):
    grouped=defaultdict(lambda:[0,0])
    for s,y in rows:grouped[float(s)][int(y)]+=1
    pos=sum(v[1] for v in grouped.values());neg=sum(v[0] for v in grouped.values())
    if not pos or not neg:return float('nan')
    below=wins=0.
    for s in sorted(grouped):
        nn,np=grouped[s];wins+=np*(below+.5*nn);below+=nn
    return wins/(pos*neg)

def bootstrap(c,s,nboot):
    ids=sorted(set(c)|set(s));rng=random.Random(42);diffs=[]
    ac=auc([r for rows in c.values() for r in rows]);ass=auc([r for rows in s.values() for r in rows])
    for _ in range(nboot):
        sampled=[ids[rng.randrange(len(ids))] for _ in ids]
        bc=auc([r for q in sampled for r in c.get(q,[])]);bs=auc([r for q in sampled for r in s.get(q,[])])
        if not math.isnan(bc-bs):diffs.append(bc-bs)
    diffs.sort()
    lo=diffs[int(.025*len(diffs))];hi=diffs[min(len(diffs)-1,int(.975*len(diffs)))]
    return {'auroc_con':ac,'auroc_sin':ass,'diff':ac-ass,'ci95_diff':[lo,hi],
            'n_boot_validos':len(diffs),'seed':42,'question_clusters':len(ids),
            'p_bootstrap':min(1.,2*min(sum(d>=0 for d in diffs),sum(d<=0 for d in diffs))/len(diffs))}

def roc(rows):
    grouped=defaultdict(lambda:[0,0])
    for score,label in rows:grouped[float(score)][int(label)]+=1
    pos=sum(v[1] for v in grouped.values());neg=sum(v[0] for v in grouped.values())
    points=[[0.,0.]];tp=fp=0
    for score in sorted(grouped,reverse=True):
        nn,np=grouped[score];tp+=np;fp+=nn;points.append([fp/neg,tp/pos])
    area=sum((points[i][0]-points[i-1][0])*(points[i][1]+points[i-1][1])/2 for i in range(1,len(points)))
    assert abs(area-auc(rows))<1e-12
    return points

def p1_stats(raw,ledger,excluded,ab_as_c=False):
    models={};ps={};masks={}
    for tag in TAGS:
        arms={};row={}
        for arm in ['sin','con']:
            qs=[q for q in raw[(tag,arm)] if q['id'] not in excluded];assert len(qs)==53-len(excluded)
            outcomes={}
            for q in qs:
                choice=ledger[(tag,arm,q['id'])]['adjudicated_choice']
                if ab_as_c and (tag,arm,q['id'])==('qwen7b','sin',3):choice='c'
                outcomes[q['id']]=choice in ['a','b','c'] and choice==q['respuesta_correcta']
                masks[(tag,arm,q['id'])]=outcomes[q['id']]
            arms[arm]=outcomes;times=[q['latency_seconds'] for q in qs]
            quartiles=statistics.quantiles(times,n=4,method='inclusive')
            correct=sum(outcomes.values());n=len(qs);p=correct/n
            row[arm]={'n':n,'correct':correct,'errors':n-correct,'accuracy_pct':100*p,
                      'accuracy_wald_ci95_pct':[100*(p-1.96*math.sqrt(p*(1-p)/n)),100*(p+1.96*math.sqrt(p*(1-p)/n))],
                      'median_seconds':statistics.median(times),'q1_seconds':quartiles[0],'q3_seconds':quartiles[2]}
        ids=sorted(arms['sin']);diff=[int(arms['con'][i])-int(arms['sin'][i]) for i in ids]
        b=diff.count(1);c=diff.count(-1);mean=statistics.mean(diff);se=statistics.stdev(diff)/math.sqrt(len(diff))
        ps[tag]=exact_mcnemar(b,c)
        row.update({'delta_rag_pp':100*mean,'paired_ci95_pp':[100*(mean-1.96*se),100*(mean+1.96*se)],
                    'b_mejora':b,'c_empeora':c,'mcnemar_p':ps[tag],
                    'median_difference_seconds':row['con']['median_seconds']-row['sin']['median_seconds']})
        models[tag]=row
    for tag,p in holm(ps).items():models[tag]['mcnemar_p_holm']=p
    pooled={arm:{'correct':sum(v[arm]['correct'] for v in models.values()),'n':4*(53-len(excluded)),
                 'errors':sum(v[arm]['errors'] for v in models.values())} for arm in ['sin','con']}
    for arm,v in pooled.items():v['accuracy_pct']=100*v['correct']/v['n']
    pooled['delta_rag_pp']=pooled['con']['accuracy_pct']-pooled['sin']['accuracy_pct']
    return {'models':models,'pooled_descriptive':pooled},masks

def judge_stats(rawjudges,masks,excluded,nboot):
    result={};all_roc={}
    for name,raw in rawjudges.items():
        rows=[r for r in raw if not r.get('autojuicio') and r.get('prob_correcta') is not None and r['id'] not in excluded]
        grouped={arm:defaultdict(list) for arm in ['sin','con']};sensitivity={}
        for arm in ['sin','con']:
            sub=[r for r in rows if r['arm']==arm]
            for r in sub:
                y=masks[(r['tag'],arm,r['id'])];grouped[arm][r['id']].append((r['prob_correcta'],int(y)))
            errors=[r for r in sub if not masks[(r['tag'],arm,r['id'])]]
            flagged=sum(r['fiable'] is False for r in errors)
            sensitivity[arm]={'n_rows':len(sub),'correct':len(sub)-len(errors),'errors':len(errors),'flagged':flagged,
                              'pct':100*flagged/len(errors),'ci95_wilson_pct':[100*x for x in wilson(flagged,len(errors))]}
        result[name]={'n_input':len(raw),'n_useful':len(rows),'n_self_judgments_input':sum(bool(r.get('autojuicio')) for r in raw),
                      'sensitivity':sensitivity,'auroc':bootstrap(grouped['con'],grouped['sin'],nboot)}
        all_roc[name]={arm:{'points':roc([r for group in grouped[arm].values() for r in group]),'n':sensitivity[arm]['n_rows']} for arm in ['sin','con']}
    return result,all_roc

def p2_stats(rows,excluded):
    selected=[r for r in rows if not (r['bank']=='original' and r['id'] in excluded)]
    groups={};models={};p_bad={};p_cov={}
    for tag in TAGS:
        row={};groups[tag]={}
        for arm in ['sin','con']:
            sub=[r for r in selected if r['model_tag']==tag and r['arm']==arm]
            orig=[r for r in sub if r['bank']=='original'];ood=[r for r in sub if r['bank']=='ood'];trapd=[r for r in sub if r['bank']=='trap' and r['gold']=='d'];trapc=[r for r in sub if r['bank']=='trap' and r['gold']!='d']
            assert len(orig)==53-len(excluded) and len(ood)==18 and len(trapd)==11 and len(trapc)==13
            groups[tag][arm]={(r['bank'],r['id']):r for r in sub}
            def is_answer(r):return r['adjudicated_choice'] in ['a','b','c']
            def is_unsupported(r):return r['adjudicated_choice'] in ['a','b','c'] or r.get('substantive_answer') is True
            def unknown(r):return r['adjudicated_choice'] is None and r.get('substantive_answer') is None
            bad=ood+trapd
            row[arm]={'ood':proportion(sum(is_unsupported(r) for r in ood),18),
                      'trap_d':proportion(sum(is_unsupported(r) for r in trapd),11),
                      'sycophancy':proportion(sum(r['adjudicated_choice']==r['accepts_false_premise_choice'] for r in trapc),13),
                      'coverage':proportion(sum(is_answer(r) for r in orig),len(orig)),
                      'explicit_abstention_original':sum(r['adjudicated_choice']=='d' for r in orig),
                      'unresolved_original':sum(r['adjudicated_choice'] is None for r in orig),
                      'unsupported':proportion(sum(is_unsupported(r) for r in bad),29),
                      'unresolved_gold_d':sum(unknown(r) for r in bad),
                      'status_counts':dict(__import__('collections').Counter(r['response_status'] for r in sub)),
                      'correct_original':sum(r['adjudicated_choice']==r['gold'] for r in orig),
                      'n_original':len(orig),'total_responses':len(sub)}
        b=c=bc=cc=0
        uncertain_pairs=0
        for key,s in groups[tag]['sin'].items():
            con=groups[tag]['con'][key]
            if s['gold']=='d':
                bs=s['adjudicated_choice'] in ['a','b','c'] or s.get('substantive_answer') is True
                bcon=con['adjudicated_choice'] in ['a','b','c'] or con.get('substantive_answer') is True
                b+=int(bs and not bcon);c+=int(bcon and not bs)
                uncertain_pairs+=int((s['adjudicated_choice'] is None and s.get('substantive_answer') is None) or (con['adjudicated_choice'] is None and con.get('substantive_answer') is None))
            if s['bank']=='original':
                cs=s['adjudicated_choice'] in ['a','b','c'];ccn=con['adjudicated_choice'] in ['a','b','c']
                bc+=int(ccn and not cs);cc+=int(cs and not ccn)
        p_bad[tag]=exact_mcnemar(b,c);p_cov[tag]=exact_mcnemar(bc,cc)
        row['paired_unsupported']={'b_avoids':b,'c_induces':c,'p':p_bad[tag],'uncertain_pairs':uncertain_pairs}
        row['paired_coverage']={'b_answers':bc,'c_stops_answering':cc,'p':p_cov[tag]};models[tag]=row
    for tag,p in holm(p_bad).items():models[tag]['paired_unsupported']['p_holm']=p
    for tag,p in holm(p_cov).items():models[tag]['paired_coverage']['p_holm']=p
    pooled={}
    for arm in ['sin','con']:
        k=sum(v[arm]['unsupported']['k'] for v in models.values());u=sum(v[arm]['unresolved_gold_d'] for v in models.values())
        pooled[arm]={'unsupported':proportion(k,116),'unresolved_gold_d':u,'unsupported_identification_bounds_pct':[100*k/116,100*(k+u)/116],
                     'coverage':proportion(sum(v[arm]['coverage']['k'] for v in models.values()),4*(53-len(excluded)))}
    return {'models':models,'pooled_descriptive':pooled,'total_responses':len(selected),
            'warning':'Unsupported incidence treats unresolved records as not positively identified; upper bounds show all unresolved gold-D records as unsupported. Refusals and explicit abstentions are separately classified.'}

def validate_ledgers(data_root,p1doc,p2doc):
    cache={}
    for proto,doc,expected in [('P1',p1doc,424),('P2',p2doc,760)]:
        if doc is None:continue
        rows=doc['records'];assert len(rows)==expected
        keys=[(r['model_tag'],r['arm'],r['bank'],r['id']) for r in rows]
        assert len(set(keys))==expected, f'{proto}: duplicate ledger keys'
        for r in rows:
            path=(data_root/r['source_file'].replace('\\','/')).resolve()
            assert path.is_relative_to(data_root.resolve())
            assert digest(path)==r['source_sha256'],f'{proto}: source SHA mismatch'
            if path not in cache:
                raw=load(path)['questions'];cache[path]={q['id']:q for q in raw}
                assert len(raw)==len(cache[path]),f'{proto}: duplicate raw IDs'
                if proto=='P1':assert set(cache[path])==set(range(1,54))
            q=cache[path][r['id']]
            assert q['respuesta_correcta']==r['gold'],f'{proto}: changed gold label'
            assert q['opcion_detectada']==r['stored_choice']
            assert q['es_correcta']==r['stored_correct']
            target=r.get('response_sha256',r.get('raw_response_sha256'))
            assert hashlib.sha256(q['respuesta_ia'].encode('utf-8')).hexdigest()==target
            assert r['adjudicated_choice'] in ['a','b','c','d',None]
            assert r['include_primary']==(not (r['bank']=='original' and r['id'] in EXCLUSIONS['primary']))
            assert r['include_sensitivity']==(not (r['bank']=='original' and r['id'] in EXCLUSIONS['sensitivity_images_only']))
            if proto=='P2' and r['bank']=='trap' and r['gold']!='d':
                meta={q['id']:q for q in load(data_root/'datasets/dataset_trap_validado.json')}
                assert r['accepts_false_premise_choice']==meta[r['id']]['opcion_que_acepta_la_premisa']
        assert sum(r['include_primary'] for r in rows)==(392 if proto=='P1' else 728)
        assert sum(r['include_sensitivity'] for r in rows)==(408 if proto=='P1' else 744)
    manifest=load(data_root/'SOURCE_MANIFEST.json')
    for name,r in manifest.items():assert digest(data_root/name.replace('\\','/'))==r['sha256'],f'Manifest SHA mismatch: {name}'

def validate_judges(rawjudges,raw):
    original={(tag,arm,q['id']):q for (tag,arm),rows in raw.items() for q in rows}
    for name,rows in rawjudges.items():
        keys=[(r['tag'],r['arm'],r['id']) for r in rows]
        assert len(keys)==len(set(keys))
        own='qwen7b' if name=='qwen' else 'llama8b'
        for r,key in zip(rows,keys):
            assert key in original
            assert r['es_correcta']==original[key]['es_correcta']
            assert r['respuesta_correcta']==original[key]['respuesta_correcta']
            assert bool(r['autojuicio'])==(r['tag']==own)
            if r.get('prob_correcta') is not None:assert 0<=r['prob_correcta']<=1

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--data-root',type=Path,default=HERE/'data_inputs')
    ap.add_argument('--out-dir',type=Path,default=HERE)
    ap.add_argument('--n-boot',type=int,default=10000)
    args=ap.parse_args();args.out_dir.mkdir(exist_ok=True,parents=True)
    ledgerdoc=load(args.data_root/'p1_choice_ledger.json');ledger={(r['model_tag'],r['arm'],r['id']):r for r in ledgerdoc['records']}
    raw={(tag,arm):load(args.data_root/'p1'/f'{tag}_{arm}.json')['questions'] for tag in TAGS for arm in ['sin','con']}
    assert len(ledger)==424 and sum(len(v) for v in raw.values())==424
    rawjudges={name:load(args.data_root/'judges'/f'{name}.json') for name in ['qwen','llama']}
    p2file=args.data_root/'p2_choice_ledger.json'
    if not p2file.is_file():raise FileNotFoundError('The complete P2 adjudication ledger is required')
    p2doc=load(p2file)
    validate_ledgers(args.data_root,ledgerdoc,p2doc)
    validate_judges(rawjudges,raw)
    results={'schema_version':1,'post_hoc_revision':True,'n_boot':args.n_boot,'seed':42,'choice_policy':ledgerdoc['policy'],
             'input_hashes':{p.relative_to(args.data_root).as_posix():digest(p) for p in sorted(args.data_root.rglob('*.json'))}}
    rocdata={}
    for name,excluded in EXCLUSIONS.items():
        p1,masks=p1_stats(raw,ledger,excluded);judges,curves=judge_stats(rawjudges,masks,excluded,args.n_boot)
        out={'excluded_original_ids':excluded,'n_original_items':53-len(excluded),'p1':p1,'detectability':judges}
        if p2doc:out['p2']=p2_stats(p2doc['records'],excluded)
        else:out['p2_status']='pending ledger from parallel audit'
        results[name]=out;rocdata[name]=curves
    # Sensitivity to the one non-single-letter P1 response; no primary relabelling.
    results['qwen_AB_as_C_sensitivity']={}
    for name,excluded in EXCLUSIONS.items():
        p1,masks=p1_stats(raw,ledger,excluded,True);judges,_=judge_stats(rawjudges,masks,excluded,args.n_boot)
        results['qwen_AB_as_C_sensitivity'][name]={'p1':p1,'detectability':judges}
    if (args.data_root/'retrieval_flags.json').exists():
        flags=load(args.data_root/'retrieval_flags.json')['records']
        for name,excluded in EXCLUSIONS.items():
            chosen=[r for r in flags if r['id'] not in excluded]
            results[name]['retrieval_proxy']=proportion(sum(r['lexical_overlap_hit'] for r in chosen),len(chosen))
    write(args.out_dir/'final_results.json',results);write(args.out_dir/'roc_points.json',rocdata)
    print(json.dumps({'p2_ledger_loaded':bool(p2doc),'cohorts':{k:{'n':v['n_original_items'],'p1':v['p1'],'judges':v['detectability']} for k,v in results.items() if k in EXCLUSIONS}},indent=2))

if __name__=='__main__':main()
