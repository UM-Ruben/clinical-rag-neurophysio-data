#!/usr/bin/env python3
"""Draw the revised ROC as a vector PDF (ReportLab; no inference or SciPy)."""
import argparse
import json
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,black,white
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import reportlab

HERE=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--results',type=Path,default=HERE/'final_results.json')
    ap.add_argument('--points',type=Path,default=HERE/'roc_points.json')
    ap.add_argument('--out',type=Path,default=HERE/'fig_roc_detectabilidad.pdf')
    args=ap.parse_args()
    fontpath=Path(reportlab.__file__).resolve().parent/'fonts'/'Vera.ttf'
    if not fontpath.is_file():raise FileNotFoundError('ReportLab bundled Vera.ttf is required for embedded plot fonts')
    pdfmetrics.registerFont(TTFont('JournalSans',str(fontpath)))
    results=json.loads(args.results.read_text(encoding='utf-8'))['primary']['detectability']['qwen']
    points=json.loads(args.points.read_text(encoding='utf-8'))['primary']['qwen']
    width,height=7.2*72,6.4*72
    c=canvas.Canvas(str(args.out),pagesize=(width,height),pageCompression=1,invariant=1,initialFontName='JournalSans')
    c.setTitle('Detectability by a blind judge: revised 49-item core')
    c.setAuthor('');c.setSubject('Corrected saved-response labels; self-judgments excluded')
    left,bottom=56.,49.;plotw,ploth=width-left-18.,height-bottom-49.
    def xy(x,y):return left+x*plotw,bottom+y*ploth
    c.setFillColor(white);c.rect(0,0,width,height,fill=1,stroke=0)
    c.setFont('JournalSans',10);c.setStrokeColor(HexColor('#cccccc'));c.setLineWidth(.5);c.setDash(1.2,2)
    for i in range(6):
        value=i/5;x,y=xy(value,value)
        if i not in [0,5]:
            c.line(x,bottom,x,bottom+ploth);c.line(left,y,left+plotw,y)
        c.setFillColor(black);c.drawCentredString(x,bottom-15,f'{value:.1f}')
        c.drawRightString(left-8,y-3.5,f'{value:.1f}')
    c.setDash();c.setStrokeColor(black);c.setLineWidth(.8);c.rect(left,bottom,plotw,ploth,stroke=1,fill=0)
    c.setFont('JournalSans',11);c.drawCentredString(left+plotw/2,17,'False positive rate')
    c.saveState();c.translate(16,bottom+ploth/2);c.rotate(90);c.drawCentredString(0,0,'True positive rate');c.restoreState()
    c.setFont('JournalSans',11);c.drawCentredString(left+plotw/2,height-17,'Detectability by a blind judge (Qwen-2.5-7B)')
    c.setFont('JournalSans',10);c.drawCentredString(left+plotw/2,height-31,'Self-judgments excluded; 49-item core')
    c.setStrokeColor(HexColor('#cccccc'));c.setLineWidth(1);c.setDash(1,2.5);c.line(*xy(0,0),*xy(1,1));c.setDash()
    styles=[('sin','#777777',[7,4],'without RAG'),('con','#2c7bb6',[],'with RAG')]
    for arm,color,dash,label in styles:
        c.setStrokeColor(HexColor(color));c.setLineWidth(2.1);c.setDash(dash)
        p=c.beginPath();p.moveTo(*xy(*points[arm]['points'][0]))
        for point in points[arm]['points'][1:]:p.lineTo(*xy(*point))
        c.drawPath(p,stroke=1,fill=0)
    c.setDash()
    # Same blue/grey, dashed/solid key and arm-size disclosure as the prior figure.
    boxw,boxh=245.,42.;boxx=left+plotw-boxw-8;boxy=bottom+9
    c.setFillColor(white);c.setStrokeColor(HexColor('#aaaaaa'));c.setLineWidth(.6);c.rect(boxx,boxy,boxw,boxh,fill=1,stroke=1)
    for i,(arm,color,dash,label) in enumerate(styles):
        yy=boxy+boxh-13-i*16;c.setStrokeColor(HexColor(color));c.setLineWidth(2.1);c.setDash(dash);c.line(boxx+8,yy+2,boxx+36,yy+2)
        c.setDash();c.setFillColor(black);c.setFont('JournalSans',9.2)
        area=results['auroc'][f'auroc_{arm}'];n=points[arm]['n']
        c.drawString(boxx+43,yy-1,f'{label} (AUROC = {area:.3f}, n={n})')
    c.showPage();c.save()
    print(args.out)

if __name__=='__main__':main()
