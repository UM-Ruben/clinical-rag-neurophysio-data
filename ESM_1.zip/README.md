# Online Resource 1 - Applied Intelligence

Beyond Accuracy: Retrieval and Abstention in Lightweight Neurophysiotherapy Question Answering

Authors: Rubén Fernández García; José Manuel García.
Affiliation: Universidad de Murcia, Murcia, Spain.
Corresponding author: Rubén Fernández García, ruben.fernandezg@um.es.
Submission version: 8 November 2026.
Scientific analysis version: 25 October 2026.

## Scope

This supplement accompanies the 25 October 2026 manuscript reanalysis. The original model responses, reference keys and blind-judge scores are preserved. No new inference was performed. Extraction ledgers document the post-hoc interpretation of response selections. Their rules do not validate clinical truth or every statement in the model's justification.

Primary analysis: exclude reference IDs 4 and 13 (unavailable drawings), 6 (placeholder answer option), and 12 (incomplete distractor), retaining 49 reference questions. Sensitivity analysis: exclude only IDs 4 and 13, retaining 51. The same exclusions apply across models, conditions, protocols, timing and judges. No original records are deleted or rewritten. The filtered reference banks are provided separately for inspection.

P1 has 424 original observations and nine changed extracted choices; 392 observations and eight changed extractions remain in the primary analysis. P2 has 760 original observations and 22 changed selections; 728 observations and 19 changed selections remain in the primary analysis. Five generic refusals remain in P2 and are distinguished from correct documentary abstentions. The complete reasons, response excerpts and source hashes are in the ledgers.

## Recompute

From this folder, with Python 3.10 or later:

    python recompute_results.py --data-root data_inputs --out-dir recomputed

This requires only the Python standard library and performs no network or model calls. It verifies input hashes, keys and reference labels, then recalculates counts, inclusive timing quartiles, paired intervals, exact McNemar tests, Holm adjustments, Wilson intervals, judge AUROCs and 10,000 paired question-cluster bootstrap resamples (seed 42). It also calculates the sensitivity scenario that maps Qwen's ambiguous AB response to C. The figures and conclusions in the manuscript use the primary ledger, not that sensitivity mapping.

Recreate the vector ROC plot with ReportLab installed:

    python make_roc.py --results recomputed/final_results.json --points recomputed/roc_points.json --out recomputed/fig_roc_detectabilidad.pdf

Optionally run the independent implementation with NumPy installed:

    python verify_independent.py

This cross-checks the counts, timing, exact tests and adjusted values, and separately computes pairwise AUROC and a weighted-cluster bootstrap. It does not import the primary analysis script. Its included verification report passed on the delivered data. This is computational checking of an explicitly adjudicated ledger, not independent clinical review of the answer key.

The complete statistical replay was checked on Windows and Linux. Original summary fields and stored correctness flags inside raw reports describe historical parsing and are intentionally not overwritten. Use final_results.json for the revised results. Output hashes list all JSON inputs seen by the analysis; extra documentation-only bank copies do not change the computed metrics.

## Files

- data_inputs/p1: eight immutable P1 reports.
- data_inputs/results_hallucination_p2_sanitized: 24 immutable P2 reports.
- data_inputs/judges: saved probabilities and binary reliability labels from both judges.
- data_inputs/p1_choice_ledger.json and p2_choice_ledger.json: complete extraction decisions and exclusions.
- data_inputs/datasets: original reference/TRAP/OOD banks, with the pre-existing quotation redactions retained.
- data_inputs/SOURCE_MANIFEST.json: hashes and original relative provenance for copied input files.
- final_results.json: primary 49-item and sensitivity 51-item statistics, plus the ambiguous-choice sensitivity.
- roc_points.json and fig_roc_detectabilidad.pdf: corrected curve coordinates and vector plot.
- reference_primary_49.json and reference_sensitivity_51.json: filtered copies; original IDs preserved.
- recompute_results.py, make_roc.py and verify_independent.py: executable analysis and verification.

## Interpretation

The input audit and scoring corrections were made after inspecting outputs. All conclusions are exploratory and conditional on the original answer key. Judge confidence intervals are nominal and are not adjusted across two judges. The second judge's sample was stratified using historical correctness labels; that sampling was not repeated after correction. Neither that judge nor the AI-assisted extraction audit supplies independent clinical validation. Retained items come from one source and overlap the QLoRA training domain.

## Availability and rights

Code: MIT. Author-created research data: CC BY 4.0. The supplied licence texts apply to those materials only. Attribution: Rubén Fernández García and José Manuel García, Universidad de Murcia. Preparing this identified submission supplement does not itself publish it publicly.

The complete third-party teaching documents and full retrieved passages are not included. Short source quotations already present in released records remain attributed by source metadata where available and are not covered by the authors' data licence. Pre-existing redactions of long source quotations remain unchanged. Retrieved passages are represented by provenance and fingerprints rather than complete text. Source corpus, adapter weights, training data and fine-tuning pipeline are not supplied; complete inference and QLoRA training are therefore not reproducible from this supplement. Exact model digests and some environment versions remain incompletely documented.


## Version precedence

This archive is Online Resource 1 for Applied Intelligence. It retains the corrected October 25 analysis. Historical public repository aggregates from September do not describe the current retained-item analysis. No source teaching documents, training dataset or adapter weights are added.
